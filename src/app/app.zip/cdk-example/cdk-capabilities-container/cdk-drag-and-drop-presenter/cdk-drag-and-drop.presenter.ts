import { Injectable } from '@angular/core';

@Injectable()
export class CdkDragAndDropPresenter {

    constructor() {}
}