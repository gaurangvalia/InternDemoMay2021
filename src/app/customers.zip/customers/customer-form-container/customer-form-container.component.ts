import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-form-container',
  templateUrl: './customer-form-container.component.html',
  styleUrls: ['./customer-form-container.component.scss']
})
export class CustomerFormContainerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  public customerData(value: any) {
    debugger
    console.log(value);

  }

}
