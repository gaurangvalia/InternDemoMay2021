import { Component } from '@angular/core';

@Component({
  selector: 'app-cdk-capabilities-container',
  templateUrl: './cdk-capabilities.container.html'
})
export class CdkCapabilitiesContainerComponent {
  constructor() {}
}