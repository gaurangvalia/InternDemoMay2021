import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-overlay-demo',
  templateUrl: './overlay-demo.component.html',
  styleUrls: ['./overlay-demo.component.scss']
})
export class OverlayDemoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
