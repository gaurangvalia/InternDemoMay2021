import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cdk-example',
  templateUrl: './cdk-example.component.html',
  styleUrls: ['./cdk-example.component.scss']
})
export class CdkExampleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
